```python
import os

print("Current Jupyter folder:")
print(os.getcwd())

print("\nFiles available in this folder:")
print(os.listdir())
```

    Current Jupyter folder:
    C:\Users\LENOVO
    
    Files available in this folder:
    ['.anaconda', '.conda', '.ipynb_checkpoints', '.ipython', '.jupyter', '.keras', '.matplotlib', '3D Objects', 'anaconda3', 'AppData', 'Application Data', 'Cookies', 'Documents', 'Downloads', 'Favorites', 'gensim-data', 'IntelGraphicsProfiles', 'Links', 'Local Settings', 'Music', 'My Documents', 'NetHood', 'NTUSER.DAT', 'ntuser.dat.LOG1', 'ntuser.dat.LOG2', 'NTUSER.DAT{90d0782f-64e7-11f1-8419-846627b188c2}.TxR.0.regtrans-ms', 'NTUSER.DAT{90d0782f-64e7-11f1-8419-846627b188c2}.TxR.1.regtrans-ms', 'NTUSER.DAT{90d0782f-64e7-11f1-8419-846627b188c2}.TxR.2.regtrans-ms', 'NTUSER.DAT{90d0782f-64e7-11f1-8419-846627b188c2}.TxR.blf', 'NTUSER.DAT{90d07830-64e7-11f1-8419-846627b188c2}.TM.blf', 'NTUSER.DAT{90d07830-64e7-11f1-8419-846627b188c2}.TMContainer00000000000000000001.regtrans-ms', 'NTUSER.DAT{90d07830-64e7-11f1-8419-846627b188c2}.TMContainer00000000000000000002.regtrans-ms', 'ntuser.ini', 'OneDrive', 'Practice Excercise.ipynb', 'PrintHood', 'Recent', 'Saved Games', 'Searches', 'SendTo', 'Start Menu', 'superstore_sales_1.csv', 'Superstore_Sales_Analysis_1.ipynb', 'Superstore_Sales_Analysis_2.ipynb', 'telco_customer_churn.csv', 'Templates', 'Untitled.ipynb', 'Videos']
    


```python
df = pd.read_csv("telco_customer_churn.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>gender</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>InternetService</th>
      <th>OnlineSecurity</th>
      <th>...</th>
      <th>DeviceProtection</th>
      <th>TechSupport</th>
      <th>StreamingTV</th>
      <th>StreamingMovies</th>
      <th>Contract</th>
      <th>PaperlessBilling</th>
      <th>PaymentMethod</th>
      <th>MonthlyCharges</th>
      <th>TotalCharges</th>
      <th>Churn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7590-VHVEG</td>
      <td>Female</td>
      <td>0</td>
      <td>Yes</td>
      <td>No</td>
      <td>1</td>
      <td>No</td>
      <td>No phone service</td>
      <td>DSL</td>
      <td>No</td>
      <td>...</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>Month-to-month</td>
      <td>Yes</td>
      <td>Electronic check</td>
      <td>29.85</td>
      <td>29.85</td>
      <td>No</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5575-GNVDE</td>
      <td>Male</td>
      <td>0</td>
      <td>No</td>
      <td>No</td>
      <td>34</td>
      <td>Yes</td>
      <td>No</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>One year</td>
      <td>No</td>
      <td>Mailed check</td>
      <td>56.95</td>
      <td>1889.5</td>
      <td>No</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3668-QPYBK</td>
      <td>Male</td>
      <td>0</td>
      <td>No</td>
      <td>No</td>
      <td>2</td>
      <td>Yes</td>
      <td>No</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>Month-to-month</td>
      <td>Yes</td>
      <td>Mailed check</td>
      <td>53.85</td>
      <td>108.15</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7795-CFOCW</td>
      <td>Male</td>
      <td>0</td>
      <td>No</td>
      <td>No</td>
      <td>45</td>
      <td>No</td>
      <td>No phone service</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>One year</td>
      <td>No</td>
      <td>Bank transfer (automatic)</td>
      <td>42.30</td>
      <td>1840.75</td>
      <td>No</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9237-HQITU</td>
      <td>Female</td>
      <td>0</td>
      <td>No</td>
      <td>No</td>
      <td>2</td>
      <td>Yes</td>
      <td>No</td>
      <td>Fiber optic</td>
      <td>No</td>
      <td>...</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>Month-to-month</td>
      <td>Yes</td>
      <td>Electronic check</td>
      <td>70.70</td>
      <td>151.65</td>
      <td>Yes</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
df.shape
```




    (7043, 21)




```python
df.columns
```




    Index(['customerID', 'gender', 'SeniorCitizen', 'Partner', 'Dependents',
           'tenure', 'PhoneService', 'MultipleLines', 'InternetService',
           'OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport',
           'StreamingTV', 'StreamingMovies', 'Contract', 'PaperlessBilling',
           'PaymentMethod', 'MonthlyCharges', 'TotalCharges', 'Churn'],
          dtype='str')




```python
df.isnull().sum()
```




    customerID          0
    gender              0
    SeniorCitizen       0
    Partner             0
    Dependents          0
    tenure              0
    PhoneService        0
    MultipleLines       0
    InternetService     0
    OnlineSecurity      0
    OnlineBackup        0
    DeviceProtection    0
    TechSupport         0
    StreamingTV         0
    StreamingMovies     0
    Contract            0
    PaperlessBilling    0
    PaymentMethod       0
    MonthlyCharges      0
    TotalCharges        0
    Churn               0
    dtype: int64




```python
df.info()
```

    <class 'pandas.DataFrame'>
    RangeIndex: 7043 entries, 0 to 7042
    Data columns (total 21 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   customerID        7043 non-null   str    
     1   gender            7043 non-null   str    
     2   SeniorCitizen     7043 non-null   int64  
     3   Partner           7043 non-null   str    
     4   Dependents        7043 non-null   str    
     5   tenure            7043 non-null   int64  
     6   PhoneService      7043 non-null   str    
     7   MultipleLines     7043 non-null   str    
     8   InternetService   7043 non-null   str    
     9   OnlineSecurity    7043 non-null   str    
     10  OnlineBackup      7043 non-null   str    
     11  DeviceProtection  7043 non-null   str    
     12  TechSupport       7043 non-null   str    
     13  StreamingTV       7043 non-null   str    
     14  StreamingMovies   7043 non-null   str    
     15  Contract          7043 non-null   str    
     16  PaperlessBilling  7043 non-null   str    
     17  PaymentMethod     7043 non-null   str    
     18  MonthlyCharges    7043 non-null   float64
     19  TotalCharges      7043 non-null   str    
     20  Churn             7043 non-null   str    
    dtypes: float64(1), int64(2), str(18)
    memory usage: 1.9 MB
    


```python
df.isnull().sum()
```




    customerID          0
    gender              0
    SeniorCitizen       0
    Partner             0
    Dependents          0
    tenure              0
    PhoneService        0
    MultipleLines       0
    InternetService     0
    OnlineSecurity      0
    OnlineBackup        0
    DeviceProtection    0
    TechSupport         0
    StreamingTV         0
    StreamingMovies     0
    Contract            0
    PaperlessBilling    0
    PaymentMethod       0
    MonthlyCharges      0
    TotalCharges        0
    Churn               0
    dtype: int64




```python
df.info()
```

    <class 'pandas.DataFrame'>
    RangeIndex: 7043 entries, 0 to 7042
    Data columns (total 21 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   customerID        7043 non-null   str    
     1   gender            7043 non-null   str    
     2   SeniorCitizen     7043 non-null   int64  
     3   Partner           7043 non-null   str    
     4   Dependents        7043 non-null   str    
     5   tenure            7043 non-null   int64  
     6   PhoneService      7043 non-null   str    
     7   MultipleLines     7043 non-null   str    
     8   InternetService   7043 non-null   str    
     9   OnlineSecurity    7043 non-null   str    
     10  OnlineBackup      7043 non-null   str    
     11  DeviceProtection  7043 non-null   str    
     12  TechSupport       7043 non-null   str    
     13  StreamingTV       7043 non-null   str    
     14  StreamingMovies   7043 non-null   str    
     15  Contract          7043 non-null   str    
     16  PaperlessBilling  7043 non-null   str    
     17  PaymentMethod     7043 non-null   str    
     18  MonthlyCharges    7043 non-null   float64
     19  TotalCharges      7043 non-null   str    
     20  Churn             7043 non-null   str    
    dtypes: float64(1), int64(2), str(18)
    memory usage: 1.9 MB
    


```python
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
```


```python
df["TotalCharges"].isnull().sum()
```




    np.int64(11)




```python
df["TotalCharges"].isnull().sum()
```




    np.int64(11)




```python
df = df.dropna(subset=["TotalCharges"])
```


```python
df.shape
```




    (7032, 21)




```python
df["Churn"].value_counts()
```




    Churn
    No     5163
    Yes    1869
    Name: count, dtype: int64




```python
total_customers = len(df)
```


```python
churned_customers = (df["Churn"] == "Yes").sum()
```


```python
churn_rate = (churned_customers / total_customers) * 100
print("Churn Rate:", round(churn_rate, 2), "%")
```

    Churn Rate: 26.58 %
    


```python
# Business interpretation:

Approximately 27 out of every 100 customers left the company. This indicates that customer retention is an important area for improvement.

Formula: - 
           Churn Rate = 1869/7032 * 100 = 26.58%
```


```python
bins = [-1, 12, 24, 36, 48, 60, 72]

labels = ["0-12", "13-24", "25-36", "37-48", "49-60", "61-72"]

df["TenureGroup"] = pd.cut(df["tenure"], bins=bins, labels=labels)
```


```python
df["TenureGroup"].value_counts().sort_index()
```




    TenureGroup
    0-12     2175
    13-24    1024
    25-36     832
    37-48     762
    49-60     832
    61-72    1407
    Name: count, dtype: int64




```python
tenure_churn = df.groupby("TenureGroup", observed=True)["Churn"].apply(
    lambda x: (x == "Yes").mean() * 100
)

tenure_churn.round(2)
```




    TenureGroup
    0-12     47.68
    13-24    28.71
    25-36    21.63
    37-48    19.03
    49-60    14.42
    61-72     6.61
    Name: Churn, dtype: float64




```python
contract_churn = df.groupby("Contract")["Churn"].apply(
    lambda x: (x == "Yes").mean() * 100
)

contract_churn.round(2)
```




    Contract
    Month-to-month    42.71
    One year          11.28
    Two year           2.85
    Name: Churn, dtype: float64




```python
high_risk = df[
    (df["InternetService"] == "Fiber optic") &
    (df["TechSupport"] == "No")
]

high_risk["Churn"].value_counts()
```




    Churn
    No     1129
    Yes    1101
    Name: count, dtype: int64




```python
high_risk_churn_rate = (high_risk["Churn"] == "Yes").mean() * 100

print("High-Risk Segment Churn Rate:", round(high_risk_churn_rate, 2), "%")
```

    High-Risk Segment Churn Rate: 49.37 %
    


```python
service_churn = df.groupby(
    ["InternetService", "TechSupport"]
)["Churn"].apply(
    lambda x: (x == "Yes").mean() * 100
)

service_churn.round(2)
```




    InternetService  TechSupport        
    DSL              No                     27.78
                     Yes                     9.71
    Fiber optic      No                     49.37
                     Yes                    22.63
    No               No internet service     7.43
    Name: Churn, dtype: float64




```python
churn_heatmap = service_churn.unstack().round(2)

churn_heatmap
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>TechSupport</th>
      <th>No</th>
      <th>No internet service</th>
      <th>Yes</th>
    </tr>
    <tr>
      <th>InternetService</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>DSL</th>
      <td>27.78</td>
      <td>NaN</td>
      <td>9.71</td>
    </tr>
    <tr>
      <th>Fiber optic</th>
      <td>49.37</td>
      <td>NaN</td>
      <td>22.63</td>
    </tr>
    <tr>
      <th>No</th>
      <td>NaN</td>
      <td>7.43</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
churn_heatmap.style.background_gradient(cmap="RdYlGn_r")
```




<style type="text/css">
#T_43259_row0_col0, #T_43259_row0_col1, #T_43259_row0_col2, #T_43259_row1_col1, #T_43259_row2_col1 {
  background-color: #006837;
  color: #f1f1f1;
}
#T_43259_row1_col0, #T_43259_row1_col2 {
  background-color: #a50026;
  color: #f1f1f1;
}
#T_43259_row2_col0, #T_43259_row2_col2 {
  background-color: #000000;
  color: #f1f1f1;
}
</style>
<table id="T_43259">
  <thead>
    <tr>
      <th class="index_name level0" >TechSupport</th>
      <th id="T_43259_level0_col0" class="col_heading level0 col0" >No</th>
      <th id="T_43259_level0_col1" class="col_heading level0 col1" >No internet service</th>
      <th id="T_43259_level0_col2" class="col_heading level0 col2" >Yes</th>
    </tr>
    <tr>
      <th class="index_name level0" >InternetService</th>
      <th class="blank col0" >&nbsp;</th>
      <th class="blank col1" >&nbsp;</th>
      <th class="blank col2" >&nbsp;</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_43259_level0_row0" class="row_heading level0 row0" >DSL</th>
      <td id="T_43259_row0_col0" class="data row0 col0" >27.780000</td>
      <td id="T_43259_row0_col1" class="data row0 col1" >nan</td>
      <td id="T_43259_row0_col2" class="data row0 col2" >9.710000</td>
    </tr>
    <tr>
      <th id="T_43259_level0_row1" class="row_heading level0 row1" >Fiber optic</th>
      <td id="T_43259_row1_col0" class="data row1 col0" >49.370000</td>
      <td id="T_43259_row1_col1" class="data row1 col1" >nan</td>
      <td id="T_43259_row1_col2" class="data row1 col2" >22.630000</td>
    </tr>
    <tr>
      <th id="T_43259_level0_row2" class="row_heading level0 row2" >No</th>
      <td id="T_43259_row2_col0" class="data row2 col0" >nan</td>
      <td id="T_43259_row2_col1" class="data row2 col1" >7.430000</td>
      <td id="T_43259_row2_col2" class="data row2 col2" >nan</td>
    </tr>
  </tbody>
</table>





```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(8, 5))

sns.heatmap(
    churn_heatmap,
    annot=True,
    fmt=".2f",
    cmap="RdYlGn_r",
    linewidths=0.5
)

plt.title("Customer Churn Rate by Internet Service and Tech Support")
plt.xlabel("Tech Support")
plt.ylabel("Internet Service")
plt.show()
```


    
![png](output_28_0.png)
    



```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
