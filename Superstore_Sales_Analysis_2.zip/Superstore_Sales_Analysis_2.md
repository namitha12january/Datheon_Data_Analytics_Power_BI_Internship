```python
import pandas as pd
```


```python
df = pd.read_csv("superstore_sales_1.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Row ID</th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>...</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>CA-2017-152156</td>
      <td>11/8/2017</td>
      <td>11/11/2017</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>...</td>
      <td>42420.0</td>
      <td>South</td>
      <td>FUR-BO-10001798</td>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>Bush Somerset Collection Bookcase</td>
      <td>261.9600</td>
      <td>2.0</td>
      <td>0.00</td>
      <td>41.9136</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>CA-2017-152156</td>
      <td>11/8/2017</td>
      <td>11/11/2017</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>...</td>
      <td>42420.0</td>
      <td>South</td>
      <td>FUR-CH-10000454</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>Hon Deluxe Fabric Upholstered Stacking Chairs,...</td>
      <td>731.9400</td>
      <td>3.0</td>
      <td>0.00</td>
      <td>219.5820</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>CA-2017-138688</td>
      <td>6/12/2017</td>
      <td>6/16/2017</td>
      <td>Second Class</td>
      <td>DV-13045</td>
      <td>Darrin Van Huff</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>...</td>
      <td>90036.0</td>
      <td>West</td>
      <td>OFF-LA-10000240</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>Self-Adhesive Address Labels for Typewriters b...</td>
      <td>14.6200</td>
      <td>2.0</td>
      <td>0.00</td>
      <td>6.8714</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>US-2016-108966</td>
      <td>10/11/2016</td>
      <td>10/18/2016</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>...</td>
      <td>33311.0</td>
      <td>South</td>
      <td>FUR-TA-10000577</td>
      <td>Furniture</td>
      <td>Tables</td>
      <td>Bretford CR4500 Series Slim Rectangular Table</td>
      <td>957.5775</td>
      <td>5.0</td>
      <td>0.45</td>
      <td>-383.0310</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>US-2016-108966</td>
      <td>10/11/2016</td>
      <td>10/18/2016</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>...</td>
      <td>33311.0</td>
      <td>South</td>
      <td>OFF-ST-10000760</td>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>Eldon Fold 'N Roll Cart System</td>
      <td>22.3680</td>
      <td>2.0</td>
      <td>0.20</td>
      <td>2.5164</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
segment_analysis = df.groupby("Segment")[["Sales", "Profit"]].sum()
segment_analysis
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Segment</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Consumer</th>
      <td>1.161401e+06</td>
      <td>134119.2092</td>
    </tr>
    <tr>
      <th>Corporate</th>
      <td>7.061464e+05</td>
      <td>91979.1340</td>
    </tr>
    <tr>
      <th>Home Office</th>
      <td>4.296531e+05</td>
      <td>60298.6785</td>
    </tr>
  </tbody>
</table>
</div>




```python
df["Order Date"] = pd.to_datetime(df["Order Date"], errors="coerce")
```


```python
df["Year-Month"] = df["Order Date"].dt.to_period("M")
```


```python
df[["Order Date", "Year-Month"]].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order Date</th>
      <th>Year-Month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2017-11-08</td>
      <td>2017-11</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2017-11-08</td>
      <td>2017-11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2017-06-12</td>
      <td>2017-06</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016-10-11</td>
      <td>2016-10</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2016-10-11</td>
      <td>2016-10</td>
    </tr>
  </tbody>
</table>
</div>




```python
monthly_sales = df.groupby("Year-Month")["Sales"].sum()
monthly_sales.head()
```




    Year-Month
    2015-01    14236.895
    2015-02     4519.892
    2015-03    55691.009
    2015-04    28295.345
    2015-05    23648.287
    Freq: M, Name: Sales, dtype: float64




```python
import matplotlib.pyplot as plt

monthly_sales = df.groupby("Year-Month")["Sales"].sum()

monthly_sales.plot(kind="line", figsize=(12, 5), marker="o")

plt.title("Monthly Sales Trend")
plt.xlabel("Year-Month")
plt.ylabel("Total Sales")
plt.xticks(rotation=45)
plt.grid(True)
plt.tight_layout()
plt.show()
```


    
![png](output_8_0.png)
    



```python
plt.figure(figsize=(10, 6))

plt.scatter(df["Discount"], df["Profit"], alpha=0.5)

plt.title("Discount vs Profit Analysis")
plt.xlabel("Discount")
plt.ylabel("Profit")

plt.grid(True)
plt.tight_layout()
plt.show()
```


    
![png](output_9_0.png)
    



```python
total_sales = df["Sales"].sum()
total_profit = df["Profit"].sum()
total_orders = df["Order ID"].nunique()
profit_margin = (total_profit / total_sales) * 100

print("Total Sales:", round(total_sales, 2))
print("Total Profit:", round(total_profit, 2))
print("Total Orders:", total_orders)
print("Profit Margin:", round(profit_margin, 2), "%")
```

    Total Sales: 2297200.86
    Total Profit: 286397.02
    Total Orders: 5015
    Profit Margin: 12.47 %
    


```python

```


```python
# Business Observations – Superstore Sales Analysis
1. Total sales generated by the Superstore were 2,297,200.86.
2. The total profit earned was 286,397.02.
3. The dataset contains 5,015 unique customer orders.
4. The overall profit margin was 12.47%.
5. Technology generated the highest sales and profit among the three product categories.
6. The West region recorded the highest sales and profit.
7. The Consumer segment contributed the highest sales and profit.
8. Furniture generated the lowest profit among the three product categories.

# Conclusion
The Superstore achieved positive overall profitability, with a profit margin of 12.47%. Technology products, the West region, and Consumer customers were the strongest contributors to business performance.
```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
