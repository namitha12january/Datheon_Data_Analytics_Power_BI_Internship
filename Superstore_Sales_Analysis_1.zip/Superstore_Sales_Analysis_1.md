```python
import pandas as pd
```


```python
df = pd.read_csv("superstore_sales.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Row ID</th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>...</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>CA-2017-152156</td>
      <td>11/8/2017</td>
      <td>11/11/2017</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>...</td>
      <td>42420.0</td>
      <td>South</td>
      <td>FUR-BO-10001798</td>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>Bush Somerset Collection Bookcase</td>
      <td>261.9600</td>
      <td>2.0</td>
      <td>0.00</td>
      <td>41.9136</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>CA-2017-152156</td>
      <td>11/8/2017</td>
      <td>11/11/2017</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>...</td>
      <td>42420.0</td>
      <td>South</td>
      <td>FUR-CH-10000454</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>Hon Deluxe Fabric Upholstered Stacking Chairs,...</td>
      <td>731.9400</td>
      <td>3.0</td>
      <td>0.00</td>
      <td>219.5820</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>CA-2017-138688</td>
      <td>6/12/2017</td>
      <td>6/16/2017</td>
      <td>Second Class</td>
      <td>DV-13045</td>
      <td>Darrin Van Huff</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>...</td>
      <td>90036.0</td>
      <td>West</td>
      <td>OFF-LA-10000240</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>Self-Adhesive Address Labels for Typewriters b...</td>
      <td>14.6200</td>
      <td>2.0</td>
      <td>0.00</td>
      <td>6.8714</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>US-2016-108966</td>
      <td>10/11/2016</td>
      <td>10/18/2016</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>...</td>
      <td>33311.0</td>
      <td>South</td>
      <td>FUR-TA-10000577</td>
      <td>Furniture</td>
      <td>Tables</td>
      <td>Bretford CR4500 Series Slim Rectangular Table</td>
      <td>957.5775</td>
      <td>5.0</td>
      <td>0.45</td>
      <td>-383.0310</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>US-2016-108966</td>
      <td>10/11/2016</td>
      <td>10/18/2016</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>...</td>
      <td>33311.0</td>
      <td>South</td>
      <td>OFF-ST-10000760</td>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>Eldon Fold 'N Roll Cart System</td>
      <td>22.3680</td>
      <td>2.0</td>
      <td>0.20</td>
      <td>2.5164</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
df.isnull().sum()
```




    Row ID             1
    Order ID           1
    Order Date       807
    Ship Date        807
    Ship Mode        807
    Customer ID      807
    Customer Name    807
    Segment          807
    Country          807
    City             807
    State            807
    Postal Code      818
    Region           807
    Product ID       807
    Category         807
    Sub-Category     807
    Product Name     807
    Sales            807
    Quantity         807
    Discount         807
    Profit           807
    dtype: int64




```python
df.shape
```




    (10801, 21)




```python
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Row ID</th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>...</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>CA-2017-152156</td>
      <td>11/8/2017</td>
      <td>11/11/2017</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>...</td>
      <td>42420.0</td>
      <td>South</td>
      <td>FUR-BO-10001798</td>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>Bush Somerset Collection Bookcase</td>
      <td>261.9600</td>
      <td>2.0</td>
      <td>0.00</td>
      <td>41.9136</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>CA-2017-152156</td>
      <td>11/8/2017</td>
      <td>11/11/2017</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>...</td>
      <td>42420.0</td>
      <td>South</td>
      <td>FUR-CH-10000454</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>Hon Deluxe Fabric Upholstered Stacking Chairs,...</td>
      <td>731.9400</td>
      <td>3.0</td>
      <td>0.00</td>
      <td>219.5820</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>CA-2017-138688</td>
      <td>6/12/2017</td>
      <td>6/16/2017</td>
      <td>Second Class</td>
      <td>DV-13045</td>
      <td>Darrin Van Huff</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>...</td>
      <td>90036.0</td>
      <td>West</td>
      <td>OFF-LA-10000240</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>Self-Adhesive Address Labels for Typewriters b...</td>
      <td>14.6200</td>
      <td>2.0</td>
      <td>0.00</td>
      <td>6.8714</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>US-2016-108966</td>
      <td>10/11/2016</td>
      <td>10/18/2016</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>...</td>
      <td>33311.0</td>
      <td>South</td>
      <td>FUR-TA-10000577</td>
      <td>Furniture</td>
      <td>Tables</td>
      <td>Bretford CR4500 Series Slim Rectangular Table</td>
      <td>957.5775</td>
      <td>5.0</td>
      <td>0.45</td>
      <td>-383.0310</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>US-2016-108966</td>
      <td>10/11/2016</td>
      <td>10/18/2016</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>...</td>
      <td>33311.0</td>
      <td>South</td>
      <td>OFF-ST-10000760</td>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>Eldon Fold 'N Roll Cart System</td>
      <td>22.3680</td>
      <td>2.0</td>
      <td>0.20</td>
      <td>2.5164</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>CA-2015-115812</td>
      <td>6/9/2015</td>
      <td>6/14/2015</td>
      <td>Standard Class</td>
      <td>BH-11710</td>
      <td>Brosina Hoffman</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>...</td>
      <td>90032.0</td>
      <td>West</td>
      <td>FUR-FU-10001487</td>
      <td>Furniture</td>
      <td>Furnishings</td>
      <td>Eldon Expressions Wood and Plastic Desk Access...</td>
      <td>48.8600</td>
      <td>7.0</td>
      <td>0.00</td>
      <td>14.1694</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>CA-2015-115812</td>
      <td>6/9/2015</td>
      <td>6/14/2015</td>
      <td>Standard Class</td>
      <td>BH-11710</td>
      <td>Brosina Hoffman</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>...</td>
      <td>90032.0</td>
      <td>West</td>
      <td>OFF-AR-10002833</td>
      <td>Office Supplies</td>
      <td>Art</td>
      <td>Newell 322</td>
      <td>7.2800</td>
      <td>4.0</td>
      <td>0.00</td>
      <td>1.9656</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>CA-2015-115812</td>
      <td>6/9/2015</td>
      <td>6/14/2015</td>
      <td>Standard Class</td>
      <td>BH-11710</td>
      <td>Brosina Hoffman</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>...</td>
      <td>90032.0</td>
      <td>West</td>
      <td>TEC-PH-10002275</td>
      <td>Technology</td>
      <td>Phones</td>
      <td>Mitel 5320 IP Phone VoIP phone</td>
      <td>907.1520</td>
      <td>6.0</td>
      <td>0.20</td>
      <td>90.7152</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>CA-2015-115812</td>
      <td>6/9/2015</td>
      <td>6/14/2015</td>
      <td>Standard Class</td>
      <td>BH-11710</td>
      <td>Brosina Hoffman</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>...</td>
      <td>90032.0</td>
      <td>West</td>
      <td>OFF-BI-10003910</td>
      <td>Office Supplies</td>
      <td>Binders</td>
      <td>DXL Angle-View Binders with Locking Rings by S...</td>
      <td>18.5040</td>
      <td>3.0</td>
      <td>0.20</td>
      <td>5.7825</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>CA-2015-115812</td>
      <td>6/9/2015</td>
      <td>6/14/2015</td>
      <td>Standard Class</td>
      <td>BH-11710</td>
      <td>Brosina Hoffman</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>...</td>
      <td>90032.0</td>
      <td>West</td>
      <td>OFF-AP-10002892</td>
      <td>Office Supplies</td>
      <td>Appliances</td>
      <td>Belkin F5C206VTEL 6 Outlet Surge</td>
      <td>114.9000</td>
      <td>5.0</td>
      <td>0.00</td>
      <td>34.4700</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 21 columns</p>
</div>




```python
df = df.dropna(how='all')
```


```python
df.isnull().sum()
```




    Row ID             0
    Order ID           0
    Order Date       806
    Ship Date        806
    Ship Mode        806
    Customer ID      806
    Customer Name    806
    Segment          806
    Country          806
    City             806
    State            806
    Postal Code      817
    Region           806
    Product ID       806
    Category         806
    Sub-Category     806
    Product Name     806
    Sales            806
    Quantity         806
    Discount         806
    Profit           806
    dtype: int64




```python
df.shape
```




    (10800, 21)




```python
df[df["Order Date"].isnull()].head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Row ID</th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>...</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>9995</th>
      <td>Person</td>
      <td>Region</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9996</th>
      <td>Anna Andreadi</td>
      <td>West</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9997</th>
      <td>Chuck Magee</td>
      <td>East</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9998</th>
      <td>Kelly Williams</td>
      <td>Central</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9999</th>
      <td>Cassandra Brandow</td>
      <td>South</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10000</th>
      <td>Returned</td>
      <td>Order ID</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10001</th>
      <td>Yes</td>
      <td>CA-2015-100762</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10002</th>
      <td>Yes</td>
      <td>CA-2015-100762</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10003</th>
      <td>Yes</td>
      <td>CA-2015-100762</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10004</th>
      <td>Yes</td>
      <td>CA-2015-100762</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 21 columns</p>
</div>




```python
df = df.dropna(subset=["Order Date"])
df.shape
```




    (9994, 21)




```python
df.isnull().sum()
```




    Row ID            0
    Order ID          0
    Order Date        0
    Ship Date         0
    Ship Mode         0
    Customer ID       0
    Customer Name     0
    Segment           0
    Country           0
    City              0
    State             0
    Postal Code      11
    Region            0
    Product ID        0
    Category          0
    Sub-Category      0
    Product Name      0
    Sales             0
    Quantity          0
    Discount          0
    Profit            0
    dtype: int64




```python
df["Order Date"] = pd.to_datetime(df["Order Date"])
```


```python
df["Year-Month"] = df["Order Date"].dt.to_period("M")
```


```python
df[["Order Date", "Year-Month"]].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order Date</th>
      <th>Year-Month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2017-11-08</td>
      <td>2017-11</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2017-11-08</td>
      <td>2017-11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2017-06-12</td>
      <td>2017-06</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016-10-11</td>
      <td>2016-10</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2016-10-11</td>
      <td>2016-10</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = df.dropna(subset=["Postal Code"])
```


```python
df.isnull().sum()
```




    Row ID           0
    Order ID         0
    Order Date       0
    Ship Date        0
    Ship Mode        0
    Customer ID      0
    Customer Name    0
    Segment          0
    Country          0
    City             0
    State            0
    Postal Code      0
    Region           0
    Product ID       0
    Category         0
    Sub-Category     0
    Product Name     0
    Sales            0
    Quantity         0
    Discount         0
    Profit           0
    Year-Month       0
    dtype: int64




```python
df.to_csv("Cleaned_Superstore.csv", index=False)
```


```python
Category_analysis = df.groupby("Category")[["Sales", "Profit"]].sum()
category_analysis
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Category</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Furniture</th>
      <td>736879.6953</td>
      <td>17259.3458</td>
    </tr>
    <tr>
      <th>Office Supplies</th>
      <td>716837.5220</td>
      <td>121885.0358</td>
    </tr>
    <tr>
      <th>Technology</th>
      <td>834554.2730</td>
      <td>145007.6618</td>
    </tr>
  </tbody>
</table>
</div>




```python
region_analysis = df.groupby("Region")[["Sales", "Profit"]].sum()

region_analysis
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Region</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Central</th>
      <td>501239.8908</td>
      <td>39706.3625</td>
    </tr>
    <tr>
      <th>East</th>
      <td>669851.8700</td>
      <td>89277.8017</td>
    </tr>
    <tr>
      <th>South</th>
      <td>391721.9050</td>
      <td>46749.4303</td>
    </tr>
    <tr>
      <th>West</th>
      <td>725457.8245</td>
      <td>108418.4489</td>
    </tr>
  </tbody>
</table>
</div>




```python
segment_analysis = df.groupby("Segment")[["Sales", "Profit"]].sum()
segment_analysis
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Segment</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Consumer</th>
      <td>1.160049e+06</td>
      <td>133744.0932</td>
    </tr>
    <tr>
      <th>Corporate</th>
      <td>6.998641e+05</td>
      <td>90445.9067</td>
    </tr>
    <tr>
      <th>Home Office</th>
      <td>4.283584e+05</td>
      <td>59962.0435</td>
    </tr>
  </tbody>
</table>
</div>




```python
monthly_sales = df.groupby("Year-Month")["Sales"].sum()

monthly_sales.plot(
    kind="line",
    figsize=(12, 5),
    title="Monthly Sales Trend"
)
```




    <Axes: title={'center': 'Monthly Sales Trend'}, xlabel='Year-Month'>




    
![png](output_21_1.png)
    



```python
df.plot(
    kind="scatter",
    x="Discount",
    y="Profit",
    figsize=(8, 5),
    title="Discount vs Profit"
)
```




    <Axes: title={'center': 'Discount vs Profit'}, xlabel='Discount', ylabel='Profit'>




    
![png](output_22_1.png)
    



```python
# Business Observations
1. Product Category: Technology generates the highest sales and profit, while Furniture generates the lowest profit.
2. Region: The West region has the highest sales and profit, while the South region has the lowest sales.
3. Customer Segment: The Consumer segment contributes the highest sales and profit, followed by Corporate and Home Office.
4. Monthly Sales: The monthly sales trend helps identify changes in sales over time and highlights months with higher or lower sales.
5. Discount vs Profit: The scatter plot helps identify the relationship between discounts and profit. Higher discounts may reduce profitability, so discount strategies should be reviewed.
```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
